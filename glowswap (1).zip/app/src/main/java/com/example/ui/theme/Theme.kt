package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = RosePrimaryDark,
    onPrimary = RoseOnPrimaryDark,
    primaryContainer = RoseContainerDark,
    onPrimaryContainer = RoseOnContainerDark,
    secondary = ChampagneSecondaryDark,
    onSecondary = ChampagneOnSecondaryDark,
    secondaryContainer = ChampagneContainerDark,
    onSecondaryContainer = ChampagneOnContainerDark,
    tertiary = MintTertiaryDark,
    onTertiary = MintOnTertiaryDark,
    tertiaryContainer = MintContainerDark,
    onTertiaryContainer = MintOnContainerDark,
    background = BeautyBackgroundDark,
    onBackground = BeautyOnBackgroundDark,
    surface = BeautySurfaceDark,
    onSurface = BeautyOnSurfaceDark,
    surfaceVariant = BeautySurfaceVariantDark,
    onSurfaceVariant = BeautyOnSurfaceVariantDark,
    outline = BeautyOutlineDark
)

private val LightColorScheme = lightColorScheme(
    primary = RosePrimaryLight,
    onPrimary = RoseOnPrimaryLight,
    primaryContainer = RoseContainerLight,
    onPrimaryContainer = RoseOnContainerLight,
    secondary = ChampagneSecondaryLight,
    onSecondary = ChampagneOnSecondaryLight,
    secondaryContainer = ChampagneContainerLight,
    onSecondaryContainer = ChampagneOnContainerLight,
    tertiary = MintTertiaryLight,
    onTertiary = MintOnTertiaryLight,
    tertiaryContainer = MintContainerLight,
    onTertiaryContainer = MintOnContainerLight,
    background = BeautyBackgroundLight,
    onBackground = BeautyOnBackgroundLight,
    surface = BeautySurfaceLight,
    onSurface = BeautyOnSurfaceLight,
    surfaceVariant = BeautySurfaceVariantLight,
    onSurfaceVariant = BeautyOnSurfaceVariantLight,
    outline = BeautyOutlineLight
)

@Composable
fun GlowSwapTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Default to false so our brand rose-champagne palette shines consistently
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Keep alias for backwards compatibility
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    GlowSwapTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}
