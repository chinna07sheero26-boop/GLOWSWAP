package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.BatchCodeResult
import com.example.data.model.BeautyCondition
import com.example.data.model.BeautyProduct
import com.example.data.model.CartItem
import com.example.data.model.OrderRecord
import com.example.data.model.PriceOffer
import com.example.data.repository.BeautyResaleRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class SortOption(val label: String) {
    RECOMMENDED("Featured"),
    DISCOUNT("Biggest Savings %"),
    PRICE_LOW("Price: Low to High"),
    PRICE_HIGH("Price: High to Low"),
    NEWEST("Newly Listed")
}

data class FilterState(
    val query: String,
    val category: String,
    val condition: BeautyCondition?,
    val sort: SortOption,
    val onlyVerified: Boolean
)

class GlowSwapViewModel(
    private val repository: BeautyResaleRepository
) : ViewModel() {

    // Filters and search
    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow("All")
    val selectedCondition = MutableStateFlow<BeautyCondition?>(null)
    val selectedSort = MutableStateFlow(SortOption.RECOMMENDED)
    val onlyVerifiedBatch = MutableStateFlow(false)

    // Navigation and inspection state
    val selectedProduct = MutableStateFlow<BeautyProduct?>(null)
    val batchCheckResult = MutableStateFlow<BatchCodeResult?>(null)

    // Checkout and promo
    val promoCode = MutableStateFlow("")
    val discountPercent = MutableStateFlow(0)
    val promoMessage = MutableStateFlow("")
    val completedOrder = MutableStateFlow<OrderRecord?>(null)
    val isCheckingOut = MutableStateFlow(false)

    // Raw streams from repository
    val allProducts: StateFlow<List<BeautyProduct>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteProducts: StateFlow<List<BeautyProduct>> = repository.favoriteProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userListings: StateFlow<List<BeautyProduct>> = repository.userListings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartItems: StateFlow<List<CartItem>> = repository.cartItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<OrderRecord>> = repository.orders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val offers: StateFlow<List<PriceOffer>> = repository.offers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val filterState = combine(
        searchQuery,
        selectedCategory,
        selectedCondition,
        selectedSort,
        onlyVerifiedBatch
    ) { query, category, condition, sort, onlyVerified ->
        FilterState(query, category, condition, sort, onlyVerified)
    }

    // Filtered and sorted products flow
    val filteredProducts: StateFlow<List<BeautyProduct>> = combine(
        allProducts,
        filterState
    ) { products, filter ->
        var result = products.filter { !it.isSold }

        // Category filter
        if (filter.category != "All") {
            result = result.filter { it.category.equals(filter.category, ignoreCase = true) }
        }

        // Condition filter
        if (filter.condition != null) {
            result = result.filter { it.condition == filter.condition }
        }

        // Verified batch code
        if (filter.onlyVerified) {
            result = result.filter { it.batchVerified }
        }

        // Search Query
        if (filter.query.isNotBlank()) {
            val q = filter.query.trim().lowercase()
            result = result.filter {
                it.title.lowercase().contains(q) ||
                        it.brand.lowercase().contains(q) ||
                        it.shade.lowercase().contains(q) ||
                        it.category.lowercase().contains(q)
            }
        }

        // Sorting
        when (filter.sort) {
            SortOption.RECOMMENDED -> result.sortedByDescending { it.sellerRating }
            SortOption.DISCOUNT -> result.sortedByDescending { it.discountPercent }
            SortOption.PRICE_LOW -> result.sortedBy { it.resalePrice }
            SortOption.PRICE_HIGH -> result.sortedByDescending { it.resalePrice }
            SortOption.NEWEST -> result.sortedByDescending { it.createdAt }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Cart calculations
    val cartSubtotal: StateFlow<Double> = cartItems.combine(discountPercent) { items, _ ->
        items.sumOf { it.product.resalePrice * it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun onSearchQueryChange(newQuery: String) {
        searchQuery.value = newQuery
    }

    fun onCategorySelect(category: String) {
        selectedCategory.value = category
    }

    fun onConditionSelect(condition: BeautyCondition?) {
        selectedCondition.value = if (selectedCondition.value == condition) null else condition
    }

    fun onSortSelect(sort: SortOption) {
        selectedSort.value = sort
    }

    fun toggleOnlyVerified() {
        onlyVerifiedBatch.value = !onlyVerifiedBatch.value
    }

    fun selectProduct(product: BeautyProduct?) {
        selectedProduct.value = product
    }

    fun toggleFavorite(product: BeautyProduct) {
        viewModelScope.launch {
            repository.toggleFavorite(product.id, product.isFavorite)
        }
    }

    fun addToBag(product: BeautyProduct) {
        viewModelScope.launch {
            repository.addToCart(product.id)
        }
    }

    fun updateCartQuantity(cartItemId: String, currentQty: Int, delta: Int) {
        viewModelScope.launch {
            val newQty = currentQty + delta
            repository.updateCartQuantity(cartItemId, newQty)
        }
    }

    fun removeFromCart(cartItemId: String) {
        viewModelScope.launch {
            repository.removeFromCart(cartItemId)
        }
    }

    fun applyPromoCode(code: String) {
        val trimmed = code.trim().uppercase()
        promoCode.value = trimmed
        if (trimmed == "GLOW15" || trimmed == "BEAUTY15") {
            discountPercent.value = 15
            promoMessage.value = "15% VIP discount applied!"
        } else if (trimmed == "FIRST10" || trimmed == "GLOW10") {
            discountPercent.value = 10
            promoMessage.value = "10% Welcome discount applied!"
        } else if (trimmed.isNotBlank()) {
            discountPercent.value = 0
            promoMessage.value = "Invalid code. Try GLOW15"
        } else {
            discountPercent.value = 0
            promoMessage.value = ""
        }
    }

    fun completeCheckout(onSuccess: (OrderRecord) -> Unit) {
        viewModelScope.launch {
            isCheckingOut.value = true
            val items = cartItems.value
            val subtotal = items.sumOf { it.product.resalePrice * it.quantity }
            val discount = subtotal * (discountPercent.value / 100.0)
            val shipping = if (subtotal > 35.0 || subtotal == 0.0) 0.0 else 4.50
            val protectionFee = 1.50
            val total = subtotal - discount + shipping + protectionFee

            val order = repository.checkout(items, total)
            completedOrder.value = order
            isCheckingOut.value = false
            onSuccess(order)
        }
    }

    fun makeOffer(product: BeautyProduct, offerAmount: Double) {
        viewModelScope.launch {
            repository.makeOffer(
                productId = product.id,
                productTitle = product.title,
                brand = product.brand,
                originalListingPrice = product.resalePrice,
                offeredPrice = offerAmount
            )
        }
    }

    fun checkBatchCode(brand: String, code: String) {
        batchCheckResult.value = repository.verifyBatchCode(brand, code)
    }

    fun createListing(
        title: String,
        brand: String,
        category: String,
        shade: String,
        originalRetailPrice: Double,
        resalePrice: Double,
        condition: BeautyCondition,
        batchCode: String,
        hasReceipt: Boolean,
        description: String,
        imageUrl: String
    ) {
        viewModelScope.launch {
            val isBatchValid = batchCode.isNotBlank() && batchCode.length >= 3
            val defaultImg = if (imageUrl.isNotBlank()) imageUrl else when (category) {
                "Skincare" -> "https://images.unsplash.com/photo-1608248597359-5834f3b584ec?auto=format&fit=crop&w=600&q=80"
                "Fragrance" -> "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=600&q=80"
                "Haircare" -> "https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?auto=format&fit=crop&w=600&q=80"
                "Tools" -> "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=600&q=80"
                else -> "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=600&q=80"
            }

            val newProduct = BeautyProduct(
                id = UUID.randomUUID().toString(),
                title = title.trim(),
                brand = brand.trim(),
                category = category,
                shade = shade.trim(),
                originalPrice = originalRetailPrice,
                resalePrice = resalePrice,
                condition = condition,
                usagePercentage = if (condition == BeautyCondition.BNIB) 100 else 95,
                batchCode = batchCode.trim().uppercase(),
                batchVerified = isBatchValid,
                hasReceiptProof = hasReceipt,
                imageUrl = defaultImg,
                description = description.trim(),
                isUserListing = true,
                createdAt = System.currentTimeMillis()
            )
            repository.createNewListing(newProduct)
        }
    }
}
