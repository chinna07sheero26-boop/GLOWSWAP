package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Beauty Palette
val RosePrimaryLight = Color(0xFF9E2A52)
val RoseOnPrimaryLight = Color(0xFFFFFFFF)
val RoseContainerLight = Color(0xFFFFD9E2)
val RoseOnContainerLight = Color(0xFF3E001D)

val ChampagneSecondaryLight = Color(0xFF8C5835)
val ChampagneOnSecondaryLight = Color(0xFFFFFFFF)
val ChampagneContainerLight = Color(0xFFFFDCC7)
val ChampagneOnContainerLight = Color(0xFF341700)

val MintTertiaryLight = Color(0xFF2E6A4F) // For authenticity & verification badges
val MintOnTertiaryLight = Color(0xFFFFFFFF)
val MintContainerLight = Color(0xFFB7F0CC)
val MintOnContainerLight = Color(0xFF002112)

val BeautyBackgroundLight = Color(0xFFFFF8F7)
val BeautyOnBackgroundLight = Color(0xFF22191B)
val BeautySurfaceLight = Color(0xFFFFFFFF)
val BeautyOnSurfaceLight = Color(0xFF22191B)
val BeautySurfaceVariantLight = Color(0xFFF4DDDF)
val BeautyOnSurfaceVariantLight = Color(0xFF524345)
val BeautyOutlineLight = Color(0xFFD6BFC3)

// Dark Beauty Palette (Luxury Velvet Evening)
val RosePrimaryDark = Color(0xFFFFB1C8)
val RoseOnPrimaryDark = Color(0xFF5E002C)
val RoseContainerDark = Color(0xFF7E123E)
val RoseOnContainerDark = Color(0xFFFFD9E2)

val ChampagneSecondaryDark = Color(0xFFF9B98E)
val ChampagneOnSecondaryDark = Color(0xFF4C270A)
val ChampagneContainerDark = Color(0xFF6B3E1E)
val ChampagneOnContainerDark = Color(0xFFFFDCC7)

val MintTertiaryDark = Color(0xFF9BD4B1)
val MintOnTertiaryDark = Color(0xFF003822)
val MintContainerDark = Color(0xFF145138)
val MintOnContainerDark = Color(0xFFB7F0CC)

val BeautyBackgroundDark = Color(0xFF191113)
val BeautyOnBackgroundDark = Color(0xFFF0DFE0)
val BeautySurfaceDark = Color(0xFF22171A)
val BeautyOnSurfaceDark = Color(0xFFF0DFE0)
val BeautySurfaceVariantDark = Color(0xFF524345)
val BeautyOnSurfaceVariantDark = Color(0xFFD6BFC3)
val BeautyOutlineDark = Color(0xFF9E8C90)

// Accent Colors
val GoldAccent = Color(0xFFD4AF37)
val VerifiedGreen = Color(0xFF1B8A5A)
val VerifiedGreenBg = Color(0xFFE8F7F0)
val SaleRed = Color(0xFFD92D20)
val StarGold = Color(0xFFF79009)
val ConditionBadgeBg = Color(0xFFFFF0F3)
val ConditionBadgeText = Color(0xFF9E2A52)
