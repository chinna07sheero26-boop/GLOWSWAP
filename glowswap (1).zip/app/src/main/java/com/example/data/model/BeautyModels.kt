package com.example.data.model

data class BeautyProduct(
    val id: String,
    val title: String,
    val brand: String,
    val category: String, // Skincare, Makeup, Fragrance, Haircare, Tools
    val shade: String = "",
    val originalPrice: Double,
    val resalePrice: Double,
    val condition: BeautyCondition,
    val usagePercentage: Int = 100, // e.g. 100 for BNIB, 95 for Swatched
    val batchCode: String = "",
    val batchVerified: Boolean = true,
    val hasReceiptProof: Boolean = true,
    val imageUrl: String = "",
    val sellerName: String = "Verified Glow Seller",
    val sellerRating: Float = 4.9f,
    val sellerSalesCount: Int = 34,
    val description: String = "",
    val isFavorite: Boolean = false,
    val isUserListing: Boolean = false,
    val isSold: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    val discountPercent: Int
        get() = if (originalPrice > resalePrice && originalPrice > 0) {
            (((originalPrice - resalePrice) / originalPrice) * 100).toInt()
        } else 0
}

enum class BeautyCondition(val displayName: String, val shortCode: String, val badgeColorHex: Long) {
    BNIB("Brand New In Box", "BNIB", 0xFF1B8A5A),
    BNNB("Brand New No Box", "BNNB", 0xFF2E6A4F),
    SWATCHED("Swatched Once (Sanitized)", "Swatched", 0xFF8C5835),
    GENTLY_USED("Gently Used (90%+ Left)", "Gently Used", 0xFF9E2A52)
}

data class CartItem(
    val id: String,
    val product: BeautyProduct,
    val quantity: Int = 1
)

data class OrderRecord(
    val id: String,
    val orderNumber: String,
    val productTitle: String,
    val brand: String,
    val imageUrl: String,
    val totalAmount: Double,
    val status: String, // Processing, Shipped, Delivered
    val trackingNumber: String,
    val orderDate: Long = System.currentTimeMillis()
)

data class PriceOffer(
    val id: String,
    val productId: String,
    val productTitle: String,
    val brand: String,
    val originalListingPrice: Double,
    val offeredPrice: Double,
    val status: String, // Pending, Accepted, Countered, Declined
    val createdAt: Long = System.currentTimeMillis()
)

data class BatchCodeResult(
    val brand: String,
    val batchCode: String,
    val isValid: Boolean,
    val productionDate: String,
    val shelfLifeRemaining: String,
    val statusMessage: String
)
