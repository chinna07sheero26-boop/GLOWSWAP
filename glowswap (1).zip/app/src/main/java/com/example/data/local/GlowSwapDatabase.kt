package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ProductEntity::class,
        CartItemEntity::class,
        OrderEntity::class,
        OfferEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class GlowSwapDatabase : RoomDatabase() {

    abstract fun glowSwapDao(): GlowSwapDao

    companion object {
        @Volatile
        private var INSTANCE: GlowSwapDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): GlowSwapDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GlowSwapDatabase::class.java,
                    "glowswap_database"
                )
                    .addCallback(GlowSwapDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class GlowSwapDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database.glowSwapDao())
                }
            }
        }

        private suspend fun populateInitialData(dao: GlowSwapDao) {
            val initialProducts = listOf(
                ProductEntity(
                    id = "p-1",
                    title = "Soft Pinch Liquid Blush",
                    brand = "Rare Beauty",
                    category = "Makeup",
                    shade = "Hope - Nude Mauve",
                    originalPrice = 23.00,
                    resalePrice = 14.50,
                    condition = "BNIB",
                    usagePercentage = 100,
                    batchCode = "3L02",
                    batchVerified = true,
                    hasReceiptProof = true,
                    imageUrl = "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=600&q=80",
                    sellerName = "Elena B.",
                    sellerRating = 4.95f,
                    sellerSalesCount = 52,
                    description = "Brand new in box! Bought during the Sephora sale but already have this exact shade. Factory sealed with verified batch code.",
                    isFavorite = true,
                    isUserListing = false,
                    isSold = false,
                    createdAt = System.currentTimeMillis() - 3600000L * 2
                ),
                ProductEntity(
                    id = "p-2",
                    title = "Cheirosa 68 Beija Flor Perfume Mist",
                    brand = "Sol de Janeiro",
                    category = "Fragrance",
                    shade = "90ml / 3.0 fl oz",
                    originalPrice = 38.00,
                    resalePrice = 22.00,
                    condition = "SWATCHED",
                    usagePercentage = 95,
                    batchCode = "24K08A",
                    batchVerified = true,
                    hasReceiptProof = true,
                    imageUrl = "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=600&q=80",
                    sellerName = "Chloe Glow",
                    sellerRating = 4.88f,
                    sellerSalesCount = 29,
                    description = "Spritzed exactly twice to test scent profile. 95% full. Brazilian Jasmine & Pink Dragonfruit notes. Sprayer sanitized.",
                    isFavorite = false,
                    isUserListing = false,
                    isSold = false,
                    createdAt = System.currentTimeMillis() - 3600000L * 6
                ),
                ProductEntity(
                    id = "p-3",
                    title = "Pillow Talk Lip Cheat Liner",
                    brand = "Charlotte Tilbury",
                    category = "Makeup",
                    shade = "Pillow Talk Original",
                    originalPrice = 25.00,
                    resalePrice = 16.00,
                    condition = "BNIB",
                    usagePercentage = 100,
                    batchCode = "B34A",
                    batchVerified = true,
                    hasReceiptProof = true,
                    imageUrl = "https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=600&q=80",
                    sellerName = "Sarah Studio",
                    sellerRating = 5.0f,
                    sellerSalesCount = 88,
                    description = "Iconic nude-pink waterproof lip pencil. Never sharpened, completely pristine in original gilded box.",
                    isFavorite = true,
                    isUserListing = false,
                    isSold = false,
                    createdAt = System.currentTimeMillis() - 3600000L * 10
                ),
                ProductEntity(
                    id = "p-4",
                    title = "Watermelon Glow Niacinamide Dew Drops",
                    brand = "Glow Recipe",
                    category = "Skincare",
                    shade = "40ml Full Size",
                    originalPrice = 35.00,
                    resalePrice = 19.50,
                    condition = "BNNB",
                    usagePercentage = 100,
                    batchCode = "G23091",
                    batchVerified = true,
                    hasReceiptProof = false,
                    imageUrl = "https://images.unsplash.com/photo-1608248597359-5834f3b584ec?auto=format&fit=crop&w=600&q=80",
                    sellerName = "SkincareLover21",
                    sellerRating = 4.7f,
                    sellerSalesCount = 14,
                    description = "Part of a holiday vault gift set. Pump has never been primed or pumped. Gives an incredible glass skin glow.",
                    isFavorite = false,
                    isUserListing = false,
                    isSold = false,
                    createdAt = System.currentTimeMillis() - 3600000L * 16
                ),
                ProductEntity(
                    id = "p-5",
                    title = "Sauvage Eau de Parfum",
                    brand = "Dior",
                    category = "Fragrance",
                    shade = "60ml / 2.0 oz",
                    originalPrice = 125.00,
                    resalePrice = 78.00,
                    condition = "GENTLY_USED",
                    usagePercentage = 90,
                    batchCode = "3M01",
                    batchVerified = true,
                    hasReceiptProof = true,
                    imageUrl = "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=600&q=80",
                    sellerName = "Marcus K.",
                    sellerRating = 4.9f,
                    sellerSalesCount = 37,
                    description = "Over 90% juice remaining. Stored in dark, temperature-controlled fragrance cabinet. Batch code verified authentic Dior.",
                    isFavorite = false,
                    isUserListing = false,
                    isSold = false,
                    createdAt = System.currentTimeMillis() - 3600000L * 24
                ),
                ProductEntity(
                    id = "p-6",
                    title = "Glossier You Eau de Parfum Rollerball",
                    brand = "Glossier",
                    category = "Fragrance",
                    shade = "8ml Rollerball",
                    originalPrice = 32.00,
                    resalePrice = 18.00,
                    condition = "SWATCHED",
                    usagePercentage = 98,
                    batchCode = "GL-882",
                    batchVerified = true,
                    hasReceiptProof = true,
                    imageUrl = "https://images.unsplash.com/photo-1616949755610-8c9bbc08f138?auto=format&fit=crop&w=600&q=80",
                    sellerName = "Mia Thorne",
                    sellerRating = 4.92f,
                    sellerSalesCount = 41,
                    description = "Rolled once on wrist. Clean iris and warm ambrox notes that adjust to your skin chemistry. Sanitized rollerball tip.",
                    isFavorite = false,
                    isUserListing = false,
                    isSold = false,
                    createdAt = System.currentTimeMillis() - 3600000L * 30
                ),
                ProductEntity(
                    id = "p-7",
                    title = "Gloss Bomb Universal Lip Luminizer",
                    brand = "Fenty Beauty",
                    category = "Makeup",
                    shade = "Fenty Glow - Shimmering Rose Nude",
                    originalPrice = 21.00,
                    resalePrice = 12.00,
                    condition = "BNIB",
                    usagePercentage = 100,
                    batchCode = "FB902",
                    batchVerified = true,
                    hasReceiptProof = true,
                    imageUrl = "https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=600&q=80",
                    sellerName = "Jessica R.",
                    sellerRating = 4.85f,
                    sellerSalesCount = 19,
                    description = "Brand new in box! Unopened seal. Smells like peach-vanilla. Purchased directly from Fenty site with receipt.",
                    isFavorite = false,
                    isUserListing = false,
                    isSold = false,
                    createdAt = System.currentTimeMillis() - 3600000L * 36
                ),
                ProductEntity(
                    id = "p-8",
                    title = "Hyaluronic Acid 2% + B5",
                    brand = "The Ordinary",
                    category = "Skincare",
                    shade = "30ml Dropper",
                    originalPrice = 9.90,
                    resalePrice = 5.50,
                    condition = "BNIB",
                    usagePercentage = 100,
                    batchCode = "DE-110",
                    batchVerified = true,
                    hasReceiptProof = true,
                    imageUrl = "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=600&q=80",
                    sellerName = "Nora P.",
                    sellerRating = 5.0f,
                    sellerSalesCount = 63,
                    description = "Brand new sealed bottle. Multi-depth hydration support. Great add-on item to bundle with free shipping!",
                    isFavorite = false,
                    isUserListing = false,
                    isSold = false,
                    createdAt = System.currentTimeMillis() - 3600000L * 42
                )
            )
            dao.insertProducts(initialProducts)

            // Seed sample past order
            val sampleOrder = OrderEntity(
                id = "ord-1",
                orderNumber = "GS-847291-US",
                productTitle = "Magic Cream Moisturizer",
                brand = "Charlotte Tilbury",
                imageUrl = "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=600&q=80",
                totalAmount = 42.50,
                status = "Delivered",
                trackingNumber = "9400100000000000000000",
                orderDate = System.currentTimeMillis() - 86400000L * 3
            )
            dao.insertOrder(sampleOrder)

            // Seed sample offer
            val sampleOffer = OfferEntity(
                id = "off-1",
                productId = "p-1",
                productTitle = "Soft Pinch Liquid Blush",
                brand = "Rare Beauty",
                originalListingPrice = 14.50,
                offeredPrice = 12.00,
                status = "Countered: $13.00",
                createdAt = System.currentTimeMillis() - 3600000L * 4
            )
            dao.insertOffer(sampleOffer)
        }
    }
}
