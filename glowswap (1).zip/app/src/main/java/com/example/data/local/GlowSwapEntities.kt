package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.BeautyCondition
import com.example.data.model.BeautyProduct

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val title: String,
    val brand: String,
    val category: String,
    val shade: String,
    val originalPrice: Double,
    val resalePrice: Double,
    val condition: String, // BNIB, BNNB, SWATCHED, GENTLY_USED
    val usagePercentage: Int,
    val batchCode: String,
    val batchVerified: Boolean,
    val hasReceiptProof: Boolean,
    val imageUrl: String,
    val sellerName: String,
    val sellerRating: Float,
    val sellerSalesCount: Int,
    val description: String,
    val isFavorite: Boolean,
    val isUserListing: Boolean,
    val isSold: Boolean,
    val createdAt: Long
) {
    fun toDomain(): BeautyProduct {
        val parsedCondition = try {
            BeautyCondition.valueOf(condition)
        } catch (e: Exception) {
            BeautyCondition.BNIB
        }
        return BeautyProduct(
            id = id,
            title = title,
            brand = brand,
            category = category,
            shade = shade,
            originalPrice = originalPrice,
            resalePrice = resalePrice,
            condition = parsedCondition,
            usagePercentage = usagePercentage,
            batchCode = batchCode,
            batchVerified = batchVerified,
            hasReceiptProof = hasReceiptProof,
            imageUrl = imageUrl,
            sellerName = sellerName,
            sellerRating = sellerRating,
            sellerSalesCount = sellerSalesCount,
            description = description,
            isFavorite = isFavorite,
            isUserListing = isUserListing,
            isSold = isSold,
            createdAt = createdAt
        )
    }

    companion object {
        fun fromDomain(product: BeautyProduct): ProductEntity {
            return ProductEntity(
                id = product.id,
                title = product.title,
                brand = product.brand,
                category = product.category,
                shade = product.shade,
                originalPrice = product.originalPrice,
                resalePrice = product.resalePrice,
                condition = product.condition.name,
                usagePercentage = product.usagePercentage,
                batchCode = product.batchCode,
                batchVerified = product.batchVerified,
                hasReceiptProof = product.hasReceiptProof,
                imageUrl = product.imageUrl,
                sellerName = product.sellerName,
                sellerRating = product.sellerRating,
                sellerSalesCount = product.sellerSalesCount,
                description = product.description,
                isFavorite = product.isFavorite,
                isUserListing = product.isUserListing,
                isSold = product.isSold,
                createdAt = product.createdAt
            )
        }
    }
}

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val quantity: Int
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val id: String,
    val orderNumber: String,
    val productTitle: String,
    val brand: String,
    val imageUrl: String,
    val totalAmount: Double,
    val status: String,
    val trackingNumber: String,
    val orderDate: Long
)

@Entity(tableName = "offers")
data class OfferEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val productTitle: String,
    val brand: String,
    val originalListingPrice: Double,
    val offeredPrice: Double,
    val status: String,
    val createdAt: Long
)
