package com.example.data.repository

import com.example.data.local.CartItemEntity
import com.example.data.local.GlowSwapDao
import com.example.data.local.OfferEntity
import com.example.data.local.OrderEntity
import com.example.data.local.ProductEntity
import com.example.data.model.BatchCodeResult
import com.example.data.model.BeautyCondition
import com.example.data.model.BeautyProduct
import com.example.data.model.CartItem
import com.example.data.model.OrderRecord
import com.example.data.model.PriceOffer
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.util.UUID

class BeautyResaleRepository(private val dao: GlowSwapDao) {

    val allProducts: Flow<List<BeautyProduct>> = dao.getAllProducts().map { list ->
        list.map { it.toDomain() }
    }

    val favoriteProducts: Flow<List<BeautyProduct>> = dao.getFavoriteProducts().map { list ->
        list.map { it.toDomain() }
    }

    val userListings: Flow<List<BeautyProduct>> = dao.getUserListings().map { list ->
        list.map { it.toDomain() }
    }

    val cartItems: Flow<List<CartItem>> = combine(
        dao.getCartItems(),
        dao.getAllProducts()
    ) { cartEntities, productEntities ->
        val productMap = productEntities.associateBy { it.id }
        cartEntities.mapNotNull { cartEntity ->
            val product = productMap[cartEntity.productId]?.toDomain()
            if (product != null) {
                CartItem(
                    id = cartEntity.id,
                    product = product,
                    quantity = cartEntity.quantity
                )
            } else null
        }
    }

    val orders: Flow<List<OrderRecord>> = dao.getAllOrders().map { list ->
        list.map {
            OrderRecord(
                id = it.id,
                orderNumber = it.orderNumber,
                productTitle = it.productTitle,
                brand = it.brand,
                imageUrl = it.imageUrl,
                totalAmount = it.totalAmount,
                status = it.status,
                trackingNumber = it.trackingNumber,
                orderDate = it.orderDate
            )
        }
    }

    val offers: Flow<List<PriceOffer>> = dao.getAllOffers().map { list ->
        list.map {
            PriceOffer(
                id = it.id,
                productId = it.productId,
                productTitle = it.productTitle,
                brand = it.brand,
                originalListingPrice = it.originalListingPrice,
                offeredPrice = it.offeredPrice,
                status = it.status,
                createdAt = it.createdAt
            )
        }
    }

    suspend fun getProductById(id: String): BeautyProduct? {
        return dao.getProductById(id)?.toDomain()
    }

    suspend fun toggleFavorite(productId: String, currentFav: Boolean) {
        dao.updateFavorite(productId, !currentFav)
    }

    suspend fun addToCart(productId: String) {
        val existingCart = dao.getProductById(productId) ?: return
        dao.insertCartItem(
            CartItemEntity(
                id = UUID.randomUUID().toString(),
                productId = productId,
                quantity = 1
            )
        )
    }

    suspend fun updateCartQuantity(cartItemId: String, quantity: Int) {
        if (quantity <= 0) {
            dao.deleteCartItem(cartItemId)
        } else {
            dao.updateCartQuantity(cartItemId, quantity)
        }
    }

    suspend fun removeFromCart(cartItemId: String) {
        dao.deleteCartItem(cartItemId)
    }

    suspend fun createNewListing(product: BeautyProduct) {
        val entity = ProductEntity.fromDomain(
            product.copy(
                isUserListing = true,
                sellerName = "You (Glow Member)",
                sellerRating = 5.0f,
                sellerSalesCount = 1
            )
        )
        dao.insertProduct(entity)
    }

    suspend fun deleteListing(productId: String) {
        dao.deleteProduct(productId)
    }

    suspend fun makeOffer(
        productId: String,
        productTitle: String,
        brand: String,
        originalListingPrice: Double,
        offeredPrice: Double
    ) {
        // Automatic negotiation simulation:
        // If offered price >= 85% of asking: Accepted!
        // If between 70% and 85%: Counter-offered at halfway
        // If < 70%: Declined
        val discountRatio = offeredPrice / originalListingPrice
        val status = when {
            discountRatio >= 0.85 -> "Accepted! Ready for Checkout"
            discountRatio >= 0.70 -> {
                val counter = String.format("%.2f", (originalListingPrice + offeredPrice) / 2)
                "Counter Offer from Seller: $$counter"
            }
            else -> "Declined by Seller (Offer too low)"
        }

        val offer = OfferEntity(
            id = UUID.randomUUID().toString(),
            productId = productId,
            productTitle = productTitle,
            brand = brand,
            originalListingPrice = originalListingPrice,
            offeredPrice = offeredPrice,
            status = status,
            createdAt = System.currentTimeMillis()
        )
        dao.insertOffer(offer)
    }

    suspend fun checkout(cartList: List<CartItem>, total: Double): OrderRecord {
        val orderNum = "GS-" + (100000..999999).random() + "-US"
        val tracking = "9400" + (1000000000000000L..9999999999999999L).random()
        val firstItem = cartList.firstOrNull()
        val title = if (cartList.size > 1) {
            "${firstItem?.product?.title ?: "Beauty Bundle"} + ${cartList.size - 1} more"
        } else {
            firstItem?.product?.title ?: "Beauty Order"
        }
        val brand = firstItem?.product?.brand ?: "GlowSwap Verified"
        val img = firstItem?.product?.imageUrl ?: ""

        val order = OrderEntity(
            id = UUID.randomUUID().toString(),
            orderNumber = orderNum,
            productTitle = title,
            brand = brand,
            imageUrl = img,
            totalAmount = total,
            status = "Processing (Shipped in 24h)",
            trackingNumber = tracking,
            orderDate = System.currentTimeMillis()
        )
        dao.insertOrder(order)

        // Mark items as sold
        cartList.forEach {
            dao.markAsSold(it.product.id)
        }
        // Clear cart
        dao.clearCart()

        return OrderRecord(
            id = order.id,
            orderNumber = order.orderNumber,
            productTitle = order.productTitle,
            brand = order.brand,
            imageUrl = order.imageUrl,
            totalAmount = order.totalAmount,
            status = order.status,
            trackingNumber = order.trackingNumber,
            orderDate = order.orderDate
        )
    }

    fun verifyBatchCode(brand: String, code: String): BatchCodeResult {
        val cleanCode = code.trim().uppercase()
        if (cleanCode.length < 3) {
            return BatchCodeResult(
                brand = brand,
                batchCode = cleanCode,
                isValid = false,
                productionDate = "Unknown",
                shelfLifeRemaining = "N/A",
                statusMessage = "Batch code format too short. Check bottle bottom or crimp."
            )
        }

        // Realistic cosmetics batch code algorithm
        val yearLetter = cleanCode.firstOrNull()
        val year = when (yearLetter) {
            '1', 'A' -> "2021"
            '2', 'B' -> "2022"
            '3', 'C', 'G' -> "2023"
            '4', 'D', 'K' -> "2024"
            '5', 'E', 'L' -> "2025"
            else -> "2024"
        }
        val monthNames = listOf("January", "March", "May", "July", "September", "November")
        val randomMonth = monthNames[Math.abs(cleanCode.hashCode()) % monthNames.size]

        return BatchCodeResult(
            brand = brand.ifBlank { "Verified Manufacturer" },
            batchCode = cleanCode,
            isValid = true,
            productionDate = "$randomMonth $year",
            shelfLifeRemaining = "24-30 Months Remaining (Fresh)",
            statusMessage = "Authentic Manufacturer Batch Code confirmed in GlowSwap database."
        )
    }
}
