package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Sell
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material.icons.outlined.Sell
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.data.local.GlowSwapDatabase
import com.example.data.repository.BeautyResaleRepository
import com.example.ui.screens.BatchCheckerScreen
import com.example.ui.screens.CartScreen
import com.example.ui.screens.MarketplaceScreen
import com.example.ui.screens.ProductDetailScreen
import com.example.ui.screens.ProfileOrdersScreen
import com.example.ui.screens.SellProductScreen
import com.example.ui.theme.GlowSwapTheme
import com.example.ui.viewmodel.GlowSwapViewModel

enum class MainNavTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    SHOP("Shop", Icons.Filled.Storefront, Icons.Outlined.Storefront, "nav_shop"),
    SELL("Sell", Icons.Filled.Sell, Icons.Outlined.Sell, "nav_sell"),
    BATCH("Batch Check", Icons.Filled.QrCodeScanner, Icons.Outlined.QrCodeScanner, "nav_batch"),
    BAG("Bag", Icons.Filled.ShoppingBag, Icons.Outlined.ShoppingBag, "nav_bag"),
    PROFILE("My Glow", Icons.Filled.Person, Icons.Outlined.Person, "nav_profile")
}

class MainActivity : ComponentActivity() {

    private val viewModel: GlowSwapViewModel by viewModels {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val db = GlowSwapDatabase.getDatabase(applicationContext, lifecycleScope)
                val repository = BeautyResaleRepository(db.glowSwapDao())
                return GlowSwapViewModel(repository) as T
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            GlowSwapTheme {
                GlowSwapApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun GlowSwapApp(viewModel: GlowSwapViewModel) {
    var currentTab by remember { mutableStateOf(MainNavTab.SHOP) }
    val selectedProduct by viewModel.selectedProduct.collectAsState()
    val cartItems by viewModel.cartItems.collectAsState()

    // Back handling: If inspecting product, close detail; if on sub-tab, return to SHOP
    BackHandler(enabled = selectedProduct != null || currentTab != MainNavTab.SHOP) {
        if (selectedProduct != null) {
            viewModel.selectProduct(null)
        } else if (currentTab != MainNavTab.SHOP) {
            currentTab = MainNavTab.SHOP
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Only show bottom navigation when not looking at product details
            if (selectedProduct == null) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    windowInsets = WindowInsets.navigationBars,
                    modifier = Modifier.testTag("main_bottom_nav")
                ) {
                    MainNavTab.values().forEach { tab ->
                        val isSelected = currentTab == tab
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentTab = tab },
                            icon = {
                                if (tab == MainNavTab.BAG) {
                                    val count = cartItems.sumOf { it.quantity }
                                    BadgedBox(
                                        badge = {
                                            if (count > 0) {
                                                Badge(
                                                    containerColor = MaterialTheme.colorScheme.primary,
                                                    contentColor = Color.White
                                                ) {
                                                    Text("$count")
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.title
                                        )
                                    }
                                } else {
                                    Icon(
                                        imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.title
                                    )
                                }
                            },
                            label = {
                                Text(
                                    text = tab.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                            ),
                            modifier = Modifier.testTag(tab.testTag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = selectedProduct to currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenTransition"
            ) { (product, tab) ->
                if (product != null) {
                    ProductDetailScreen(
                        product = product,
                        viewModel = viewModel,
                        onBack = { viewModel.selectProduct(null) },
                        onNavigateToCart = {
                            viewModel.selectProduct(null)
                            currentTab = MainNavTab.BAG
                        }
                    )
                } else {
                    when (tab) {
                        MainNavTab.SHOP -> {
                            MarketplaceScreen(
                                viewModel = viewModel,
                                onNavigateToProduct = { viewModel.selectProduct(it) },
                                onNavigateToCart = { currentTab = MainNavTab.BAG }
                            )
                        }

                        MainNavTab.SELL -> {
                            SellProductScreen(
                                viewModel = viewModel,
                                onListingCreated = {
                                    currentTab = MainNavTab.SHOP
                                }
                            )
                        }

                        MainNavTab.BATCH -> {
                            BatchCheckerScreen(viewModel = viewModel)
                        }

                        MainNavTab.BAG -> {
                            CartScreen(
                                viewModel = viewModel,
                                onContinueShopping = { currentTab = MainNavTab.SHOP },
                                onViewOrders = { currentTab = MainNavTab.PROFILE }
                            )
                        }

                        MainNavTab.PROFILE -> {
                            ProfileOrdersScreen(
                                viewModel = viewModel,
                                onNavigateToProduct = { viewModel.selectProduct(it) }
                            )
                        }
                    }
                }
            }
        }
    }
}
