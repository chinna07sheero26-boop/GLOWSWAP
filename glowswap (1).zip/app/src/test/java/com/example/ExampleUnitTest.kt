package com.example

import com.example.data.model.BeautyCondition
import com.example.data.model.BeautyProduct
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testDiscountPercentageCalculation() {
        val product = BeautyProduct(
            id = "test-1",
            title = "Test Lip Oil",
            brand = "Dior",
            category = "Makeup",
            originalPrice = 40.0,
            resalePrice = 24.0,
            condition = BeautyCondition.BNIB
        )
        // (40 - 24) / 40 = 16 / 40 = 40%
        assertEquals(40, product.discountPercent)
    }

    @Test
    fun testZeroDiscountWhenResaleIsHigherOrEqual() {
        val product = BeautyProduct(
            id = "test-2",
            title = "Limited Edition Palette",
            brand = "Chanel",
            category = "Makeup",
            originalPrice = 60.0,
            resalePrice = 60.0,
            condition = BeautyCondition.BNIB
        )
        assertEquals(0, product.discountPercent)
    }

    @Test
    fun testConditionProperties() {
        assertEquals("BNIB", BeautyCondition.BNIB.shortCode)
        assertEquals("Brand New In Box", BeautyCondition.BNIB.displayName)
        assertEquals("Swatched Once (Sanitized)", BeautyCondition.SWATCHED.displayName)
    }
}
